package org.verizon.ConsumerServiceApi.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.verizon.ConsumerServiceApi.model.EnterprisecustomerModel;

public interface EnterprisecustomerRepo  extends JpaRepository<EnterprisecustomerModel,Integer> {

}


