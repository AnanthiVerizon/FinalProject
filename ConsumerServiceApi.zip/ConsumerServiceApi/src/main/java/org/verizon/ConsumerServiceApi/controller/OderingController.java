package org.verizon.ConsumerServiceApi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.verizon.ConsumerServiceApi.model.Catalogmodel;
import org.verizon.ConsumerServiceApi.service.CatalogService;
import org.verizon.ConsumerServiceApi.service.OrderingService;

@RestController
@RequestMapping("/api/ordering")
public class OderingController {
	
	private OrderingService orderingservice;
	 
	@Autowired
	public OderingController(OrderingService orderingservice) {
		
		this.orderingservice = orderingservice;
	}
	
	@GetMapping("/allcust")
	public List<Ordering> getAllcatalogmodel(){
		return catalogservice.getAllCatalogmodel();
		
	}
	@PostMapping("/insert")
	public Catalogmodel createcatalogmodel(@RequestBody Catalogmodel catmod)
	{
		return catalogservice.createcatalogmodel(catmod);
}

}